﻿using System.Data.Entity;

namespace Polyclinic_project.Models
{
    //public class cityDbInitializer : DropCreateDatabaseAlways<PolyclinicContext>
    //{
    //    protected override void Seed(PolyclinicContext db)
    //    {
    //        db.City.Add(new Cities { City_code = 34, City_name = "Волгоград" });
    //        db.City.Add(new Cities { City_code = 61, City_name = "Ростов-на-Дону" });
    //        db.City.Add(new Cities { City_code = 77, City_name = "Москва" });
    //        base.Seed(db);
    //    }
    //}
}